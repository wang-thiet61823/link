<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>502 Bad Gateway</title>
    <style>
        body {
            text-align: center;
            padding: 50px;
        }
    </style>
</head>
<body>
    <h1>502 Bad Gateway</h1>
    <p>Sorry, something went wrong on our end. Please try again later.</p>
</body>
</html>
